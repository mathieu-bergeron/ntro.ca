package pong.frontal.evenements;

import ca.ntro.app.frontend.events.EventNtro;

public class EvtAfficherPartie extends EventNtro {

}
