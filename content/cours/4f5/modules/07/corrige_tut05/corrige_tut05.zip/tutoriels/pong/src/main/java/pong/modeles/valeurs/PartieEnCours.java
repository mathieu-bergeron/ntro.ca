package pong.modeles.valeurs;

public class PartieEnCours extends RendezVous {
	
	private String nomDeuxiemeJoueur;
	private String idPartie;

	public String getNomDeuxiemeJoueur() {
		return nomDeuxiemeJoueur;
	}

	public void setNomDeuxiemeJoueur(String nomDeuxiemeJoueur) {
		this.nomDeuxiemeJoueur = nomDeuxiemeJoueur;
	}

	public String getIdPartie() {
		return idPartie;
	}

	public void setIdPartie(String idPartie) {
		this.idPartie = idPartie;
	}
	
	
	

	public PartieEnCours() {
		super();
	}

	public PartieEnCours(String idRendezVous, 
			             String nomPremierJoueur,
			             String nomDeuxiemeJoueur,
			             String idPartie) {

		super(idRendezVous, nomPremierJoueur);

		setNomDeuxiemeJoueur(nomDeuxiemeJoueur);
		setIdPartie(idPartie);
	}
	
	
	@Override
	public String toString() {
		return super.toString() + " Vs " + nomDeuxiemeJoueur;
	}
	
	

}
