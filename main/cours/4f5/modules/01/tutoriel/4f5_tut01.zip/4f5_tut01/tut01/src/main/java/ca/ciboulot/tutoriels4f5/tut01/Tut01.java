package ca.ciboulot.tutoriels4f5.tut01;

import MON_JEU.MON_NOM.MonJeuMonNom;
import ca.ntro.app.NtroAppFx;

public class Tut01 {

	public static void main(String[] args) {
		NtroAppFx.launch(MonJeuMonNom.class, args);
	}

}